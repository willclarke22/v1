import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ScenePlanRequest = {
  prompt?: string;
  model?: string;
};

type NvidiaChatResponse = {
  choices?: Array<{
    message?: {
      content?: unknown;
    };
    finish_reason?: string;
  }>;
  usage?: {
    prompt_tokens?: number;
    completion_tokens?: number;
    total_tokens?: number;
  };
};

const NVIDIA_BASE_URL = process.env.NVIDIA_BASE_URL ?? "https://integrate.api.nvidia.com/v1";
const DEFAULT_NVIDIA_MODEL = process.env.MYWAY_NVIDIA_ANIMATION_MODEL ?? "nvidia/nemotron-3-super-120b-a12b";
const REQUEST_TIMEOUT_MS = 240_000;

function contentToString(content: unknown) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (part && typeof part === "object") {
          const record = part as Record<string, unknown>;
          if (typeof record.text === "string") return record.text;
          if (typeof record.content === "string") return record.content;
        }
        return "";
      })
      .join("")
      .trim();
  }
  return "";
}

function stripCodeFence(value: string) {
  const trimmed = value.trim();
  if (!trimmed.startsWith("```")) return trimmed;
  return trimmed.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
}

function safeParseJson(content: string) {
  const stripped = stripCodeFence(content);
  try {
    return JSON.parse(stripped) as unknown;
  } catch (error) {
    const firstBrace = stripped.indexOf("{");
    const lastBrace = stripped.lastIndexOf("}");
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      return JSON.parse(stripped.slice(firstBrace, lastBrace + 1)) as unknown;
    }
    throw error;
  }
}

function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { ...init, signal: controller.signal }).finally(() => clearTimeout(timeout));
}

function fallbackPlan(prompt: string) {
  return {
    schema_version: "myway_blender_playground_scene_v1",
    title: "Monster behind the wall",
    prompt,
    style: {
      mood: "spooky but playful",
      quality_target: "cinematic stylized still",
      palette: ["deep blue", "violet shadows", "warm doorway light", "monster green accent"],
    },
    camera: {
      framing: "medium_wide",
      angle: "low_three_quarter",
      motion: "slow_push_in",
      focus: "the wall corner where the monster is hiding",
    },
    environment: {
      kind: "corner_room",
      floor: "dark matte floor with subtle grid",
      walls: "tall hallway corner wall",
      fog: "light floor haze",
    },
    subjects: [
      {
        id: "monster",
        kind: "monster",
        role: "hiding_behind_wall",
        position_hint: "back_right",
        pose: "peeking around the wall with raised claws",
        expression: "mischievous wide eyes",
        color_hint: "green",
        scale: "large",
      },
      {
        id: "kid",
        kind: "child",
        role: "unaware_walk_by",
        position_hint: "front_left",
        pose: "walking forward while looking away",
        expression: "unaware",
        color_hint: "blue",
        scale: "small",
      },
    ],
    objects: [
      {
        id: "hiding_wall",
        kind: "wall_corner",
        position_hint: "center_right",
        purpose: "occludes most of the monster so the scene reads as a scare setup",
      },
    ],
    lighting: {
      key: "cool moonlike light from upper left",
      rim: "thin cyan rim around monster silhouette",
      practical: "warm light spill behind wall",
      shadow_strength: "strong",
    },
    effects: {
      fog: "light",
      bloom: "subtle",
      vignette: "medium",
    },
    animation_beats: [
      { frame_range: [1, 12], action: "establish corner and unaware kid" },
      { frame_range: [13, 34], action: "monster slowly leans from behind wall" },
      { frame_range: [35, 48], action: "monster eyes and claws become the focus" },
    ],
  };
}

function buildSystemPrompt() {
  return [
    "You are a cinematic Blender scene planner for a local sandbox.",
    "Return ONLY valid JSON. No markdown. No comments. No executable code.",
    "You are not writing Blender Python. You are describing a safe scene that a trusted Blender script can render.",
    "Keep the output concrete: camera, environment, subjects, objects, lighting, effects, and animation beats.",
    "Use stylized, non-graphic, readable scenes. No gore. No horror violence. A playful scare is fine.",
    "Prefer clear silhouettes, strong composition, and simple cinematic staging over complicated realism.",
  ].join("\n");
}

function buildUserPrompt(prompt: string) {
  return [
    "Create a Blender-friendly scene plan for this freeform prompt:",
    prompt,
    "",
    "Return exactly one JSON object with this shape:",
    "schema_version: \"myway_blender_playground_scene_v1\"",
    "title: short title",
    "prompt: original prompt",
    "style: { mood, quality_target, palette: string[] }",
    "camera: { framing, angle, motion, focus }",
    "environment: { kind, floor, walls, fog }",
    "subjects: 1 to 4 objects with { id, kind, role, position_hint, pose, expression, color_hint, scale }",
    "objects: 0 to 6 objects with { id, kind, position_hint, purpose }",
    "lighting: { key, rim, practical, shadow_strength }",
    "effects: { fog, bloom, vignette }",
    "animation_beats: exactly 3 beats with { frame_range, action }",
    "",
    "Allowed subject kinds: monster, child, person, robot, creature, animal, abstract_character.",
    "Allowed object kinds: wall_corner, doorway, table, chair, window, box, machine, tree, rock, generic_prop.",
    "Allowed position hints: front_left, front_right, center, back_left, back_right, center_right, center_left.",
    "Return JSON only.",
  ].join("\n");
}

export async function GET() {
  return NextResponse.json({
    ok: true,
    route: "blender-playground/scene-plan",
    default_model: DEFAULT_NVIDIA_MODEL,
    has_nvidia_api_key: Boolean(process.env.NVIDIA_API_KEY?.trim()),
  });
}

export async function POST(request: NextRequest) {
  const body = (await request.json().catch(() => ({}))) as ScenePlanRequest;
  const prompt = body.prompt?.trim() || "Create a monster hiding behind a wall about to scare a kid.";
  const model = body.model?.trim() || DEFAULT_NVIDIA_MODEL;
  const apiKey = process.env.NVIDIA_API_KEY;

  if (!apiKey?.trim()) {
    return NextResponse.json({
      ok: true,
      fallback: true,
      warning: "Missing NVIDIA_API_KEY, so the sandbox returned a deterministic fallback scene plan.",
      plan: fallbackPlan(prompt),
    });
  }

  const startedAt = Date.now();

  try {
    const response = await fetchWithTimeout(
      `${NVIDIA_BASE_URL}/chat/completions`,
      {
        method: "POST",
        headers: {
          authorization: `Bearer ${apiKey}`,
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          model,
          temperature: 0.2,
          top_p: 0.9,
          max_tokens: 2200,
          response_format: { type: "json_object" },
          chat_template_kwargs: { enable_thinking: false },
          messages: [
            { role: "system", content: buildSystemPrompt() },
            { role: "user", content: buildUserPrompt(prompt) },
          ],
        }),
      },
      REQUEST_TIMEOUT_MS,
    );

    const elapsedMs = Date.now() - startedAt;

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      return NextResponse.json({
        ok: true,
        fallback: true,
        warning: `NVIDIA request failed (${response.status}); returned fallback scene plan.`,
        detail: detail.slice(0, 800),
        plan: fallbackPlan(prompt),
      });
    }

    const data = (await response.json()) as NvidiaChatResponse;
    const content = contentToString(data.choices?.[0]?.message?.content);
    const plan = safeParseJson(content);

    return NextResponse.json({
      ok: true,
      fallback: false,
      provider: "nvidia",
      model,
      plan,
      debug: {
        elapsed_ms: elapsedMs,
        finish_reason: data.choices?.[0]?.finish_reason ?? null,
        usage: data.usage ?? null,
        raw_content_preview: content.slice(0, 1200),
      },
    });
  } catch (error) {
    return NextResponse.json({
      ok: true,
      fallback: true,
      warning: "Scene-plan generation failed; returned fallback scene plan.",
      error: error instanceof Error ? error.message : "Unknown scene-plan error",
      plan: fallbackPlan(prompt),
    });
  }
}
