import { FreeformBlenderPlaygroundLab } from "@/ui/learning-space/probes/generated-video/blender-playground/freeform-blender-playground-lab";

export default function BlenderPlaygroundPage() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,rgba(14,165,233,0.22),transparent_34%),linear-gradient(135deg,#05000b,#160620_48%,#020308)] px-6 py-6 text-white">
      <div className="mx-auto flex max-w-7xl flex-col gap-5">
        <header className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-5 shadow-2xl backdrop-blur-xl">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-cyan-100/70">
            MyWay Blender Playground · Freeform NVIDIA → Blender sandbox
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">
            Type a scene. Let the model plan it. Let Blender render it.
          </h1>
          <p className="mt-2 max-w-4xl text-sm leading-7 text-zinc-200/78">
            This sandbox intentionally ignores the MyWay learning schema. It tests the simpler pipeline first: a plain-language prompt becomes a safe Blender scene plan, then a trusted local Blender script renders a still image or short PNG frame sequence.
          </p>
        </header>

        <FreeformBlenderPlaygroundLab />
      </div>
    </main>
  );
}
