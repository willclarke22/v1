import json
import math
import os
import sys
from typing import Any, Dict, List, Tuple

import bpy
import mathutils

Vec3 = Tuple[float, float, float]
MAT: Dict[str, Any] = {}
GROUPS: Dict[str, List[Any]] = {}


def as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def clean_text(value: Any, fallback: str, max_len: int = 80) -> str:
    if not isinstance(value, str):
        return fallback[:max_len]
    text = " ".join(value.strip().split())
    return (text or fallback)[:max_len]


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def look_at(obj, target: Vec3):
    direction = mathutils.Vector((target[0] - obj.location.x, target[1] - obj.location.y, target[2] - obj.location.z))
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def make_mat(name: str, rgba, emission: float = 0.0, metallic: float = 0.0, roughness: float = 0.45, alpha: float = None):
    mat = bpy.data.materials.new(name)
    if alpha is not None:
        rgba = (rgba[0], rgba[1], rgba[2], alpha)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    if rgba[3] < 0.99:
        mat.blend_method = "BLEND"
        mat.show_transparent_back = True
        try:
            mat.use_screen_refraction = True
        except Exception:
            pass
    try:
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            if "Base Color" in bsdf.inputs:
                bsdf.inputs["Base Color"].default_value = rgba
            if "Alpha" in bsdf.inputs:
                bsdf.inputs["Alpha"].default_value = rgba[3]
            if "Metallic" in bsdf.inputs:
                bsdf.inputs["Metallic"].default_value = metallic
            if "Roughness" in bsdf.inputs:
                bsdf.inputs["Roughness"].default_value = roughness
            if "Emission Color" in bsdf.inputs:
                bsdf.inputs["Emission Color"].default_value = rgba
            if "Emission Strength" in bsdf.inputs:
                bsdf.inputs["Emission Strength"].default_value = emission
    except Exception:
        pass
    return mat


def init_materials():
    MAT["floor"] = make_mat("Playground dark polished floor", (0.018, 0.018, 0.026, 1.0), roughness=0.28)
    MAT["wall"] = make_mat("Playground blue violet wall", (0.085, 0.075, 0.12, 1.0), roughness=0.58)
    MAT["wall_edge"] = make_mat("Playground cool wall edge", (0.22, 0.34, 0.55, 1.0), emission=0.08, roughness=0.35)
    MAT["monster"] = make_mat("Playground monster green", (0.18, 0.78, 0.48, 1.0), emission=0.06, roughness=0.42)
    MAT["monster_dark"] = make_mat("Playground monster dark", (0.06, 0.22, 0.16, 1.0), roughness=0.45)
    MAT["kid_skin"] = make_mat("Playground kid skin", (0.95, 0.72, 0.54, 1.0), roughness=0.55)
    MAT["kid_blue"] = make_mat("Playground kid blue hoodie", (0.12, 0.34, 0.88, 1.0), emission=0.02, roughness=0.5)
    MAT["kid_dark"] = make_mat("Playground kid pants", (0.06, 0.07, 0.11, 1.0), roughness=0.62)
    MAT["eye"] = make_mat("Playground glowing eye white", (0.92, 1.0, 0.95, 1.0), emission=1.4, roughness=0.18)
    MAT["pupil"] = make_mat("Playground pupil", (0.005, 0.005, 0.006, 1.0), roughness=0.5)
    MAT["claw"] = make_mat("Playground small claw", (0.86, 0.95, 0.82, 1.0), emission=0.15, roughness=0.32)
    MAT["warm"] = make_mat("Playground warm hidden light", (1.0, 0.52, 0.18, 1.0), emission=1.2, roughness=0.28)
    MAT["fog"] = make_mat("Playground transparent haze", (0.42, 0.58, 0.9, 0.10), emission=0.05, roughness=0.9)
    MAT["text"] = make_mat("Playground text", (0.94, 0.97, 1.0, 1.0), emission=0.7, roughness=0.4)


def group_add(group_id: str, *objects: Any):
    GROUPS.setdefault(group_id, [])
    for obj in objects:
        if obj is not None:
            GROUPS[group_id].append(obj)


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()


def setup_scene(width: int, height: int, fps: int):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = int(width)
    scene.render.resolution_y = int(height)
    scene.render.fps = int(fps)
    scene.render.image_settings.file_format = "PNG"
    try:
        scene.eevee.taa_render_samples = 48
        scene.eevee.use_bloom = True
        scene.eevee.bloom_intensity = 0.06
        scene.eevee.use_gtao = True
        scene.eevee.gtao_factor = 1.0
    except Exception:
        pass

    world = scene.world or bpy.data.worlds.new("Playground World")
    scene.world = world
    world.color = (0.005, 0.007, 0.017)

    bpy.ops.object.camera_add(location=(-3.8, -6.6, 2.55))
    camera = bpy.context.object
    camera.name = "Playground cinematic camera"
    camera.data.lens = 42
    look_at(camera, (0.15, 0.25, 1.0))
    scene.camera = camera
    return camera


def add_light(kind: str, name: str, location: Vec3, energy: float, color, size: float = 1.0):
    bpy.ops.object.light_add(type=kind, location=location)
    light = bpy.context.object
    light.name = name
    light.data.energy = energy
    light.data.color = (color[0], color[1], color[2])
    if hasattr(light.data, "size"):
        light.data.size = size
    return light


def make_cube(name: str, location: Vec3, scale: Vec3, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    obj.data.materials.append(mat)
    return obj


def make_sphere(name: str, location: Vec3, radius: float, mat, segments: int = 32):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=max(8, segments // 2), radius=radius, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    return obj


def make_cylinder(name: str, location: Vec3, radius: float, depth: float, mat, vertices: int = 32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    return obj


def make_cone(name: str, location: Vec3, radius: float, depth: float, mat, direction: Vec3 = (0, 0, 1), vertices: int = 32):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius, radius2=0.0, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    vec = mathutils.Vector(direction)
    if vec.length == 0:
        vec = mathutils.Vector((0, 0, 1))
    obj.rotation_euler = vec.to_track_quat("Z", "Y").to_euler()
    return obj


def make_text(name: str, body: str, location: Vec3, size: float, camera, mat=None):
    curve = bpy.data.curves.new(name + " curve", type="FONT")
    curve.body = body
    curve.align_x = "CENTER"
    curve.align_y = "CENTER"
    curve.size = size
    curve.resolution_u = 8
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    obj.data.materials.append(mat or MAT["text"])
    look_at(obj, tuple(camera.location))
    return obj


def make_curve(name: str, points: List[Vec3], mat, bevel: float = 0.025):
    curve = bpy.data.curves.new(name, type="CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 24
    curve.bevel_depth = bevel
    curve.bevel_resolution = 4
    spline = curve.splines.new("POLY")
    spline.points.add(len(points) - 1)
    for point, coord in zip(spline.points, points):
        point.co = (coord[0], coord[1], coord[2], 1)
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    return obj


def make_stage(camera):
    floor = make_cube("Playground glossy floor", (0, 0, -0.04), (5.8, 4.6, 0.035), MAT["floor"])
    group_add("stage", floor)

    back_wall = make_cube("Playground back wall", (0, 1.78, 1.35), (5.8, 0.06, 1.55), MAT["wall"])
    right_wall = make_cube("Playground hiding side wall", (1.05, 0.28, 1.28), (0.09, 1.42, 1.5), MAT["wall"])
    wall_edge = make_cube("Playground glowing wall edge", (0.94, -1.1, 1.35), (0.025, 0.035, 1.42), MAT["wall_edge"])
    group_add("walls", back_wall, right_wall, wall_edge)

    # Warm hidden doorway/light spill behind the wall.
    warm_panel = make_cube("Playground warm hidden light panel", (1.28, -0.93, 1.18), (0.035, 0.52, 0.8), MAT["warm"])
    group_add("warm_light_panel", warm_panel)

    # A few subtle floor haze slabs.
    for index, y in enumerate([-1.2, -0.4, 0.45]):
        haze = make_cube(f"Playground haze slab {index + 1}", (-0.1, y, 0.08 + index * 0.02), (4.8, 0.3, 0.012), MAT["fog"])
        group_add("haze", haze)

    # Sparse perspective grid.
    for x in [-4, -3, -2, -1, 0, 1, 2, 3, 4]:
        group_add("grid", make_curve(f"floor grid x {x}", [(x * 0.55, -2.1, 0.005), (x * 0.55, 2.05, 0.005)], MAT["wall_edge"], bevel=0.0035))
    for y in [-3, -2, -1, 0, 1, 2, 3]:
        group_add("grid", make_curve(f"floor grid y {y}", [(-2.75, y * 0.55, 0.007), (2.75, y * 0.55, 0.007)], MAT["wall_edge"], bevel=0.0035))

    title = make_text("Playground title", "freeform Blender test", (0, -2.04, 2.45), 0.13, camera)
    group_add("title", title)


def make_monster(camera):
    # Parent object makes animation simple.
    parent = bpy.data.objects.new("Monster rig parent", None)
    bpy.context.collection.objects.link(parent)
    parent.location = (0.82, -0.98, 0.05)
    group_add("monster", parent)

    body = make_sphere("Monster rounded body", (1.22, -0.86, 0.78), 0.48, MAT["monster_dark"], 40)
    head = make_sphere("Monster head peeking", (0.78, -1.18, 1.32), 0.42, MAT["monster"], 48)
    eye_l = make_sphere("Monster left glowing eye", (0.55, -1.48, 1.40), 0.085, MAT["eye"], 24)
    eye_r = make_sphere("Monster right glowing eye", (0.78, -1.52, 1.43), 0.085, MAT["eye"], 24)
    pupil_l = make_sphere("Monster left pupil", (0.52, -1.56, 1.39), 0.032, MAT["pupil"], 16)
    pupil_r = make_sphere("Monster right pupil", (0.75, -1.60, 1.42), 0.032, MAT["pupil"], 16)
    horn_l = make_cone("Monster left horn", (0.56, -1.21, 1.76), 0.10, 0.32, MAT["claw"], direction=(-0.35, -0.1, 1))
    horn_r = make_cone("Monster right horn", (0.91, -1.17, 1.75), 0.10, 0.32, MAT["claw"], direction=(0.35, -0.1, 1))

    claw_objs = []
    for i, z in enumerate([1.05, 0.9, 0.75]):
        claw_objs.append(make_cone(f"Monster wall claw {i + 1}", (0.88, -1.18, z), 0.035, 0.22, MAT["claw"], direction=(-1, -0.18, 0.05), vertices=20))

    smile = make_curve("Monster mischievous smile", [(0.56, -1.58, 1.20), (0.66, -1.64, 1.15), (0.82, -1.60, 1.19)], MAT["pupil"], bevel=0.012)
    cheek = make_sphere("Monster cheek glow", (0.94, -1.45, 1.22), 0.055, MAT["warm"], 16)

    for obj in [body, head, eye_l, eye_r, pupil_l, pupil_r, horn_l, horn_r, smile, cheek, *claw_objs]:
        obj.parent = parent
        group_add("monster", obj)

    label = make_text("Monster small label", "peek", (0.68, -1.72, 1.88), 0.10, camera, MAT["wall_edge"])
    label.parent = parent
    group_add("monster", label)
    return parent


def make_kid(camera):
    parent = bpy.data.objects.new("Kid rig parent", None)
    bpy.context.collection.objects.link(parent)
    parent.location = (-1.52, -1.22, 0.02)
    group_add("kid", parent)

    head = make_sphere("Kid head", (-1.52, -1.22, 1.05), 0.18, MAT["kid_skin"], 32)
    hair = make_sphere("Kid hair cap", (-1.55, -1.25, 1.18), 0.18, MAT["kid_dark"], 24)
    body = make_cylinder("Kid hoodie", (-1.52, -1.22, 0.66), 0.16, 0.48, MAT["kid_blue"], 32)
    pants = make_cylinder("Kid pants", (-1.52, -1.22, 0.28), 0.13, 0.42, MAT["kid_dark"], 24)
    backpack = make_cube("Kid backpack", (-1.74, -1.06, 0.62), (0.10, 0.09, 0.23), MAT["warm"])
    arm = make_cylinder("Kid small arm", (-1.32, -1.25, 0.64), 0.045, 0.38, MAT["kid_skin"], 16)
    arm.rotation_euler = (math.radians(65), 0, math.radians(-25))

    for obj in [head, hair, body, pants, backpack, arm]:
        obj.parent = parent
        group_add("kid", obj)

    thought = make_text("Kid unaware label", "unaware", (-1.48, -1.55, 1.42), 0.09, camera, MAT["text"])
    thought.parent = parent
    group_add("kid", thought)
    return parent


def apply_plan_variation(plan: Dict[str, Any], camera):
    title = clean_text(plan.get("title"), "freeform Blender test", 64)
    # Rename visible title text body when present.
    for obj in GROUPS.get("title", []):
        if hasattr(obj.data, "body"):
            obj.data.body = title[:42]
            look_at(obj, tuple(camera.location))


def animate_scene(camera, monster_parent, kid_parent, frame_number: int, total_frames: int):
    t = (frame_number - 1) / max(1, total_frames - 1)
    # Camera slow push and slight orbit.
    camera.location = (-3.8 + 0.58 * t, -6.6 + 0.92 * t, 2.55 - 0.18 * t)
    look_at(camera, (0.15 + 0.12 * t, -0.12, 1.08))

    # Monster leans farther around the wall during the reveal.
    lean = clamp((t - 0.18) / 0.58, 0.0, 1.0)
    monster_parent.location.x = 0.82 - 0.24 * lean
    monster_parent.location.y = -0.98 - 0.05 * math.sin(t * math.pi)
    monster_parent.rotation_euler = (0, 0, math.radians(-5 - 8 * lean))

    # Kid walks slightly forward, still unaware.
    kid_parent.location.x = -1.52 + 0.22 * t
    kid_parent.location.y = -1.22 + 0.08 * t
    kid_parent.rotation_euler = (0, 0, math.radians(3 * math.sin(t * math.pi * 2)))

    # Subtle flicker in warm panel and eyes.
    for obj in GROUPS.get("warm_light_panel", []):
        obj.scale.x = 0.035 + 0.012 * math.sin(frame_number * 0.55)


def load_payload(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


def main():
    if len(sys.argv) < 7:
        raise SystemExit("Expected: blender --background --python render-freeform-scene.py -- input.json out_dir frames fps width height")

    input_path = sys.argv[-6]
    output_dir = sys.argv[-5]
    frames = int(sys.argv[-4])
    fps = int(sys.argv[-3])
    width = int(sys.argv[-2])
    height = int(sys.argv[-1])

    os.makedirs(output_dir, exist_ok=True)
    payload = load_payload(input_path)
    plan = as_dict(payload.get("scene_plan"))

    clear_scene()
    init_materials()
    camera = setup_scene(width, height, fps)

    make_stage(camera)
    monster_parent = make_monster(camera)
    kid_parent = make_kid(camera)
    apply_plan_variation(plan, camera)

    add_light("AREA", "Playground cool key softbox", (-3.8, -4.2, 5.6), 1200, (0.55, 0.72, 1.0), 5.5)
    add_light("AREA", "Playground monster rim", (1.9, -1.8, 2.8), 840, (0.18, 0.95, 0.65), 1.4)
    add_light("POINT", "Playground hidden warm source", (1.45, -0.95, 1.28), 430, (1.0, 0.45, 0.16), 1.0)
    add_light("AREA", "Playground overhead fill", (0.0, 1.5, 5.2), 260, (0.7, 0.72, 1.0), 6.0)

    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end = frames

    for frame in range(1, frames + 1):
        scene.frame_set(frame)
        animate_scene(camera, monster_parent, kid_parent, frame, frames)
        output_path = os.path.join(output_dir, f"frame_{frame:04d}.png")
        scene.render.filepath = output_path
        bpy.ops.render.render(write_still=True)

    print(json.dumps({"ok": True, "frames": frames, "output_dir": output_dir}))


if __name__ == "__main__":
    main()
