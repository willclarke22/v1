﻿import type {
  LearningSpaceRelationship,
  LearningSpaceRelationshipType,
  LearningSpaceRelationshipVisualStyle,
} from "@/types/learning-space";
import type {
  BuiltTopicRelationshipType,
  RelationshipEvidenceTier,
  RelationshipGraphBuildOptions,
} from "./relationship-types";

export const DEFAULT_RELATIONSHIP_GRAPH_OPTIONS = {
  /**
   * The sidebar now exposes multiple relationship lenses. The global budget
   * needs enough room for semantic/diagnostic relationship types to coexist in
   * the payload, even though only one lens is visible at a time.
   */
  maxRelationships: 72,
  maxRelationshipsPerTopic: 4,
  maxConfusionGap: 0.08,

  /**
   * Insight links are intentionally easier to emit than confusion links for the
   * current calibration phase.
   *
   * The confusion/insight model is still being improved, and insight values may
   * be less separated than we ultimately want. These links remain hidden by
   * default and non-layout-affecting; the sidebar Insight view is what reveals
   * them for visual inspection.
   */
  maxInsightGap: 0.14,
  minAverageConfusionForPattern: 0.5,
  minAverageInsightForPattern: 0.38,
  minStrength: 0.58,

  /**
   * Shallow-field fallback gate for shared diagnosis when richer diagnosisEvidence is
   * unavailable.
   */
  minMessageCountForDiagnosisOnly: 2,
  allowSharedDiagnosisWithSupportingSignals: false,

  /**
   * V1.1 evidence-aware shared diagnosis gates.
   *
   * These are intentionally conservative. A shared diagnosis relationship
   * should mean more than "both topics have the same fallback label."
   */
  minDiagnosisBeliefForSharedDiagnosis: 0.58,
  minDiagnosisConfidenceForSharedDiagnosis: 0.2,
  minDiagnosisEvidenceCountForSharedDiagnosis: 2,
  allowWeakeningDiagnosisRelationships: false,
  allowResolvedDiagnosisRelationships: false,
} satisfies Required<Omit<RelationshipGraphBuildOptions, "generatedAt">>;

export function clamp01(value: number) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

export function round4(value: number) {
  return Math.round(value * 10_000) / 10_000;
}

export function normalizeTopicLabel(label: string) {
  return label.trim() || "Untitled Topic";
}

export function makeRelationshipKey(args: {
  relationshipType: LearningSpaceRelationshipType;
  sourceTopicId: string;
  targetTopicId: string;
}) {
  const [a, b] =
    args.sourceTopicId < args.targetTopicId
      ? [args.sourceTopicId, args.targetTopicId]
      : [args.targetTopicId, args.sourceTopicId];

  return `${args.relationshipType}:${a}::${b}`;
}

export function makeRelationshipId(args: {
  relationshipType: LearningSpaceRelationshipType;
  sourceTopicId: string;
  targetTopicId: string;
}) {
  return `rel-${args.relationshipType}-${makeRelationshipKey(args)
    .replace(`${args.relationshipType}:`, "")
    .replaceAll("::", "--")}`;
}

export function defaultAffectsLayout(
  relationshipType: LearningSpaceRelationshipType,
) {
  switch (relationshipType) {
    case "semantic":
    case "semantic_similarity":
    case "same_cluster":
    case "prerequisite":
    case "transfer_bridge":
      return true;
    case "shared_diagnosis":
    case "shared_confusion_pattern":
    case "shared_insight_pattern":
    case "blocks":
    case "analogy":
    case "co_attempted":
    case "content_source_overlap":
    case "shared_confusion":
    case "strategy":
    case "temporal":
    default:
      return false;
  }
}

export function defaultVisibleByDefault(
  relationshipType: LearningSpaceRelationshipType,
  strength: number,
) {
  switch (relationshipType) {
    case "semantic":
    case "semantic_similarity":
      return strength >= 0.92;
    default:
      return false;
  }
}

export function defaultRelationshipVisualStyle(
  relationshipType: LearningSpaceRelationshipType,
): LearningSpaceRelationshipVisualStyle {
  switch (relationshipType) {
    case "blocks":
    case "prerequisite":
      return "arrow";
    case "shared_diagnosis":
    case "shared_confusion_pattern":
    case "shared_insight_pattern":
      return "dashed_line";
    case "semantic":
    case "semantic_similarity":
    case "transfer_bridge":
      return "arc";
    default:
      return "thread";
  }
}

export function evidenceTierRank(tier: RelationshipEvidenceTier | null | undefined) {
  switch (tier) {
    case "model_only":
      return 1;
    case "message_average":
      return 2;
    case "generic_attempt_interpretation":
      return 3;
    case "contract_marker_estimate":
      return 4;
    case "deterministic_structured_judgment":
      return 5;
    case "llm_rubric_judgment":
      return 6;
    case "hybrid_structured_and_rubric_judgment":
      return 7;
    case "repeated_judged_pattern":
      return 8;
    case "unknown":
    default:
      return 0;
  }
}

export function relationshipPriority(args: {
  relationshipType: LearningSpaceRelationshipType;
  strength: number;
  confidence: number;
  evidenceTier?: RelationshipEvidenceTier | null;
}) {
  const typeBoost =
    args.relationshipType === "semantic" ||
    args.relationshipType === "semantic_similarity"
      ? 0.16
      : args.relationshipType === "shared_insight_pattern"
        ? 0.06
        : args.relationshipType === "shared_diagnosis"
          ? 0.04
          : 0;

  /**
   * Evidence tier should not overpower strength/confidence, but stronger
   * judged evidence should rank above weak calibration links when values are
   * otherwise similar.
   */
  const tierBoost = clamp01(evidenceTierRank(args.evidenceTier) / 8) * 0.06;

  return round4(
    clamp01(args.strength * 0.72 + args.confidence * 0.2 + typeBoost + tierBoost),
  );
}

export function maxOpacityForRelationship(args: {
  relationshipType: LearningSpaceRelationshipType;
  strength: number;
  evidenceTier?: RelationshipEvidenceTier | null;
}) {
  if (
    args.relationshipType === "semantic" ||
    args.relationshipType === "semantic_similarity"
  ) {
    return round4(Math.max(0.16, Math.min(0.74, 0.18 + args.strength * 0.52)));
  }

  const tierRank = evidenceTierRank(args.evidenceTier);
  const tierOpacityBoost =
    args.relationshipType === "shared_diagnosis" ? Math.min(0.08, tierRank * 0.01) : 0;

  return round4(
    Math.max(0.08, Math.min(0.48, 0.1 + args.strength * 0.28 + tierOpacityBoost)),
  );
}

export function buildRelationshipDisplayPolicy(args: {
  relationshipType: LearningSpaceRelationshipType;
  strength: number;
  confidence: number;
  affectsLayout?: boolean;
  visibleByDefault?: boolean;
  evidenceTier?: RelationshipEvidenceTier | null;
}): LearningSpaceRelationship["display_policy"] {
  const affectsLayout =
    args.affectsLayout ?? defaultAffectsLayout(args.relationshipType);
  const visibleByDefault =
    args.visibleByDefault ??
    defaultVisibleByDefault(args.relationshipType, args.strength);

  return {
    show_in_overview: visibleByDefault,
    show_on_focus: true,
    visible_by_default: visibleByDefault,
    affects_layout: affectsLayout,
    max_opacity: maxOpacityForRelationship({
      relationshipType: args.relationshipType,
      strength: args.strength,
      evidenceTier: args.evidenceTier,
    }),
    visual_style: defaultRelationshipVisualStyle(args.relationshipType),
    priority: relationshipPriority({
      relationshipType: args.relationshipType,
      strength: args.strength,
      confidence: args.confidence,
      evidenceTier: args.evidenceTier,
    }),
  };
}

export function derivedRelationshipEvidenceSource(
  relationshipType: BuiltTopicRelationshipType,
  evidenceTier?: RelationshipEvidenceTier | null,
) {
  switch (relationshipType) {
    case "shared_diagnosis":
      return evidenceTier && evidenceTier !== "unknown"
        ? ["topic_diagnosis", evidenceTier]
        : ["topic_diagnosis"];
    case "shared_confusion_pattern":
      return ["topic_confusion_average"];
    case "shared_insight_pattern":
      return ["topic_insight_average"];
  }
}



