import { ProbeTemplateGallery } from "@/ui/learning-space/probes/probe-lab/probe-template-gallery";

const labLinks = [
  {
    href: "/probe-lab/generated-video",
    title: "Generated-video lab",
    body: "MyWay learning-message → director contract → Remotion/WebGL/Blender experiments.",
  },
  {
    href: "/probe-lab/blender-playground",
    title: "Blender playground",
    body: "Freeform prompt → rich scene plan → local Blender render sandbox.",
  },
];

export default function ProbeLabPage() {
  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,rgba(126,34,206,0.30),transparent_34%),linear-gradient(135deg,#11001d,#23043c_48%,#07000d)] px-6 py-6 text-white">
      <div className="mx-auto flex max-w-7xl flex-col gap-5">
        <header className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-5 shadow-2xl backdrop-blur-xl">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-purple-100/70">
            MyWay Probe Lab · Template gallery
          </p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">
            Restore and test the core probe templates
          </h1>
          <p className="mt-2 max-w-4xl text-sm leading-7 text-zinc-200/78">
            This page is the probe-template home again. Use it to inspect how single choice, multi choice, drag/drop, sequence, slider, graph, audio, and video-click probes render from EngineRenderableProbe contracts. The generated-video and Blender experiments now live on separate routes.
          </p>

          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {labLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="rounded-3xl border border-white/10 bg-black/20 p-4 transition hover:bg-white/[0.075]"
              >
                <p className="font-semibold text-white">{link.title}</p>
                <p className="mt-1 text-sm leading-6 text-zinc-300/76">{link.body}</p>
              </a>
            ))}
          </div>
        </header>

        <ProbeTemplateGallery />
      </div>
    </main>
  );
}
