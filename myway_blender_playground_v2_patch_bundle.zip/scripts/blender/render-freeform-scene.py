import json
import math
import os
import sys
from typing import Any, Dict, List, Tuple

import bpy
import mathutils

Vec3 = Tuple[float, float, float]
MAT: Dict[str, Any] = {}
GROUPS: Dict[str, List[Any]] = {}


def as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def clean_text(value: Any, fallback: str, max_len: int = 80) -> str:
    if not isinstance(value, str):
        return fallback[:max_len]
    text = " ".join(value.strip().split())
    return (text or fallback)[:max_len]


def as_bool(value: Any, fallback: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in ["true", "yes", "on", "1"]:
            return True
        if lowered in ["false", "no", "off", "0"]:
            return False
    return fallback


def as_float(value: Any, fallback: float, low: float = -999.0, high: float = 999.0) -> float:
    try:
        number = float(value)
    except Exception:
        return fallback
    if not math.isfinite(number):
        return fallback
    return max(low, min(high, number))


def as_vec3(value: Any, fallback: Vec3) -> Vec3:
    if isinstance(value, list) and len(value) >= 3:
        return (
            as_float(value[0], fallback[0], -20, 20),
            as_float(value[1], fallback[1], -20, 20),
            as_float(value[2], fallback[2], -20, 20),
        )
    return fallback


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def group_add(group_id: str, *objects: Any):
    GROUPS.setdefault(group_id, [])
    for obj in objects:
        if obj is not None:
            GROUPS[group_id].append(obj)


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()


def look_at(obj, target: Vec3, track: str = "-Z"):
    direction = mathutils.Vector((target[0] - obj.location.x, target[1] - obj.location.y, target[2] - obj.location.z))
    if direction.length == 0:
        return
    obj.rotation_euler = direction.to_track_quat(track, "Y").to_euler()


def shade_smooth(obj):
    try:
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.object.shade_smooth()
        obj.select_set(False)
    except Exception:
        pass
    return obj


def add_bevel(obj, amount: float = 0.04, segments: int = 4):
    try:
        bevel = obj.modifiers.new("soft bevel", "BEVEL")
        bevel.width = amount
        bevel.segments = segments
        bevel.affect = "EDGES"
        obj.modifiers.new("weighted normals", "WEIGHTED_NORMAL")
    except Exception:
        pass
    return obj


def make_mat(name: str, rgba, emission: float = 0.0, metallic: float = 0.0, roughness: float = 0.45, alpha: float = None):
    mat = bpy.data.materials.new(name)
    if alpha is not None:
        rgba = (rgba[0], rgba[1], rgba[2], alpha)
    mat.diffuse_color = rgba
    mat.use_nodes = True
    if rgba[3] < 0.99:
        mat.blend_method = "BLEND"
        mat.show_transparent_back = True
        try:
            mat.use_screen_refraction = True
        except Exception:
            pass
    try:
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            if "Base Color" in bsdf.inputs:
                bsdf.inputs["Base Color"].default_value = rgba
            if "Alpha" in bsdf.inputs:
                bsdf.inputs["Alpha"].default_value = rgba[3]
            if "Metallic" in bsdf.inputs:
                bsdf.inputs["Metallic"].default_value = metallic
            if "Roughness" in bsdf.inputs:
                bsdf.inputs["Roughness"].default_value = roughness
            if "Emission Color" in bsdf.inputs:
                bsdf.inputs["Emission Color"].default_value = rgba
            if "Emission Strength" in bsdf.inputs:
                bsdf.inputs["Emission Strength"].default_value = emission
    except Exception:
        pass
    return mat


def init_materials():
    MAT["floor"] = make_mat("Playground reflective obsidian floor", (0.012, 0.013, 0.020, 1.0), metallic=0.0, roughness=0.18)
    MAT["floor_grid"] = make_mat("Playground dim cyan floor grid", (0.32, 0.70, 0.92, 0.55), emission=0.18, roughness=0.35)
    MAT["wall"] = make_mat("Playground blue violet matte wall", (0.075, 0.075, 0.115, 1.0), roughness=0.52)
    MAT["wall_face"] = make_mat("Playground wall cool face", (0.115, 0.18, 0.24, 1.0), roughness=0.48)
    MAT["wall_edge"] = make_mat("Playground glowing cyan wall edge", (0.44, 0.82, 1.0, 1.0), emission=0.65, roughness=0.24)
    MAT["monster"] = make_mat("Playground monster teal rubber", (0.20, 0.82, 0.62, 1.0), emission=0.04, roughness=0.38)
    MAT["monster_dark"] = make_mat("Playground monster shaded belly", (0.07, 0.27, 0.21, 1.0), roughness=0.44)
    MAT["kid_skin"] = make_mat("Playground soft skin", (0.95, 0.72, 0.54, 1.0), roughness=0.55)
    MAT["kid_blue"] = make_mat("Playground kid blue hoodie", (0.11, 0.31, 0.82, 1.0), emission=0.01, roughness=0.50)
    MAT["kid_dark"] = make_mat("Playground kid dark pants", (0.055, 0.060, 0.088, 1.0), roughness=0.62)
    MAT["eye"] = make_mat("Playground glowing eye white", (0.94, 1.0, 0.96, 1.0), emission=1.85, roughness=0.18)
    MAT["pupil"] = make_mat("Playground glossy pupil", (0.002, 0.002, 0.003, 1.0), roughness=0.18)
    MAT["claw"] = make_mat("Playground pale horn claw", (0.86, 0.96, 0.86, 1.0), emission=0.08, roughness=0.30)
    MAT["warm"] = make_mat("Playground warm doorway glow", (1.0, 0.48, 0.16, 1.0), emission=1.8, roughness=0.26)
    MAT["fog"] = make_mat("Playground transparent blue haze", (0.42, 0.62, 1.0, 0.075), emission=0.045, roughness=0.95)
    MAT["shadow"] = make_mat("Playground soft shadow patch", (0.0, 0.0, 0.0, 0.18), roughness=0.9)
    MAT["text"] = make_mat("Playground readable text", (0.94, 0.98, 1.0, 1.0), emission=0.8, roughness=0.4)


def setup_scene(width: int, height: int, fps: int, plan: Dict[str, Any]):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_EEVEE"
    scene.render.resolution_x = int(width)
    scene.render.resolution_y = int(height)
    scene.render.fps = int(fps)
    scene.render.image_settings.file_format = "PNG"

    try:
        scene.eevee.taa_render_samples = int(as_float(as_dict(plan.get("render_quality")).get("samples"), 64, 8, 128))
        scene.eevee.use_bloom = True
        scene.eevee.bloom_intensity = 0.085
        scene.eevee.bloom_radius = 6.0
        scene.eevee.use_gtao = True
        scene.eevee.gtao_factor = 1.15
        scene.eevee.gtao_distance = 3.0
        scene.eevee.use_soft_shadows = True
    except Exception:
        pass

    try:
        scene.render.film_transparent = False
        scene.view_settings.view_transform = "Filmic"
        scene.view_settings.look = "Medium High Contrast"
        scene.view_settings.exposure = -0.15
        scene.view_settings.gamma = 1.0
    except Exception:
        pass

    world = scene.world or bpy.data.worlds.new("Playground World")
    scene.world = world
    world.color = (0.004, 0.006, 0.016)

    camera_plan = as_dict(plan.get("camera"))
    start = as_dict(camera_plan.get("start"))
    cam_pos = as_vec3(start.get("position"), (-3.9, -6.7, 2.45))
    look = as_vec3(start.get("look_at"), (0.12, -0.20, 1.05))

    bpy.ops.object.camera_add(location=cam_pos)
    camera = bpy.context.object
    camera.name = "Playground cinematic camera"
    camera.data.lens = as_float(camera_plan.get("lens_mm"), 58, 24, 90)
    try:
        camera.data.dof.use_dof = as_bool(as_dict(plan.get("render_quality")).get("use_depth_of_field"), True)
        camera.data.dof.focus_distance = 5.7
        camera.data.dof.aperture_fstop = 3.2
    except Exception:
        pass
    look_at(camera, look)
    scene.camera = camera
    return camera


def add_light(kind: str, name: str, location: Vec3, energy: float, color, size: float = 1.0):
    bpy.ops.object.light_add(type=kind, location=location)
    light = bpy.context.object
    light.name = name
    light.data.energy = energy
    light.data.color = (color[0], color[1], color[2])
    if hasattr(light.data, "size"):
        light.data.size = size
    try:
        light.data.use_shadow = True
    except Exception:
        pass
    return light


def make_cube(name: str, location: Vec3, scale: Vec3, mat, bevel: float = 0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    obj.data.materials.append(mat)
    if bevel > 0:
        add_bevel(obj, bevel, 5)
    return obj


def make_sphere(name: str, location: Vec3, radius: float, mat, segments: int = 40, scale: Vec3 = (1, 1, 1)):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=max(12, segments // 2), radius=radius, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    obj.data.materials.append(mat)
    shade_smooth(obj)
    return obj


def make_cylinder(name: str, location: Vec3, radius: float, depth: float, mat, vertices: int = 32):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    shade_smooth(obj)
    add_bevel(obj, 0.015, 3)
    return obj


def make_cone(name: str, location: Vec3, radius: float, depth: float, mat, direction: Vec3 = (0, 0, 1), vertices: int = 32):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius, radius2=0.0, depth=depth, location=location)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(mat)
    vec = mathutils.Vector(direction)
    if vec.length == 0:
        vec = mathutils.Vector((0, 0, 1))
    obj.rotation_euler = vec.to_track_quat("Z", "Y").to_euler()
    shade_smooth(obj)
    return obj


def make_text(name: str, body: str, location: Vec3, size: float, camera, mat=None):
    curve = bpy.data.curves.new(name + " curve", type="FONT")
    curve.body = body
    curve.align_x = "CENTER"
    curve.align_y = "CENTER"
    curve.size = size
    curve.resolution_u = 12
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.location = location
    obj.data.materials.append(mat or MAT["text"])
    # Text front is along local +Z. Using +Z instead of -Z avoids mirrored/backwards labels.
    look_at(obj, tuple(camera.location), track="Z")
    return obj


def make_curve(name: str, points: List[Vec3], mat, bevel: float = 0.025):
    curve = bpy.data.curves.new(name, type="CURVE")
    curve.dimensions = "3D"
    curve.resolution_u = 28
    curve.bevel_depth = bevel
    curve.bevel_resolution = 5
    spline = curve.splines.new("POLY")
    spline.points.add(len(points) - 1)
    for point, coord in zip(spline.points, points):
        point.co = (coord[0], coord[1], coord[2], 1)
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    return obj


def plan_wants_labels(plan: Dict[str, Any]) -> bool:
    rq = as_dict(plan.get("render_quality"))
    labels = clean_text(rq.get("text_labels"), "none", 20).lower()
    prompt = clean_text(plan.get("prompt"), "", 300).lower()
    return labels in ["minimal", "requested"] or "label" in prompt or "text" in prompt


def make_stage(camera, plan: Dict[str, Any]):
    floor = make_cube("Playground glossy reflective floor", (0, 0, -0.045), (6.4, 5.2, 0.035), MAT["floor"], bevel=0.035)
    group_add("stage", floor)

    back_wall = make_cube("Playground beveled back wall", (0, 1.82, 1.36), (6.2, 0.08, 1.65), MAT["wall_face"], bevel=0.045)
    side_wall = make_cube("Playground hiding occlusion wall", (1.08, 0.16, 1.31), (0.105, 1.55, 1.62), MAT["wall"], bevel=0.04)
    wall_edge = make_cube("Playground glowing wall reveal edge", (0.96, -1.20, 1.37), (0.022, 0.048, 1.48), MAT["wall_edge"], bevel=0.015)
    wall_lip = make_cube("Playground thin front wall lip", (1.02, -1.20, 0.16), (0.09, 0.05, 0.16), MAT["wall_edge"], bevel=0.02)
    group_add("walls", back_wall, side_wall, wall_edge, wall_lip)

    warm_panel = make_cube("Playground hidden warm doorway glow", (1.30, -1.03, 1.16), (0.034, 0.58, 0.86), MAT["warm"], bevel=0.018)
    group_add("warm_light_panel", warm_panel)

    # Soft shadow pools and haze layers. These are deliberately simple but cinematic.
    for index, (x, y, sx, sy, alpha_scale) in enumerate([(-1.5, -1.2, 0.90, 0.34, 1.0), (0.75, -1.15, 1.10, 0.42, 0.8), (0.0, -0.45, 2.4, 0.28, 0.5)]):
        patch = make_cube(f"Playground soft shadow patch {index + 1}", (x, y, 0.012 + index * 0.002), (sx, sy, 0.006), MAT["shadow"])
        group_add("shadows", patch)

    for index, y in enumerate([-1.45, -0.62, 0.30]):
        haze = make_cube(f"Playground blue floor haze {index + 1}", (-0.20, y, 0.075 + index * 0.018), (5.2, 0.30, 0.010), MAT["fog"])
        group_add("haze", haze)

    # Sparse perspective grid. Keep it subtle so the render feels more polished than diagrammatic.
    for x in [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]:
        group_add("grid", make_curve(f"floor grid x {x}", [(x * 0.52, -2.35, 0.012), (x * 0.52, 2.10, 0.012)], MAT["floor_grid"], bevel=0.0028))
    for y in [-4, -3, -2, -1, 0, 1, 2, 3]:
        group_add("grid", make_curve(f"floor grid y {y}", [(-2.95, y * 0.52, 0.014), (2.95, y * 0.52, 0.014)], MAT["floor_grid"], bevel=0.0028))

    if plan_wants_labels(plan):
        title = clean_text(plan.get("title"), "freeform Blender test", 48)
        group_add("title", make_text("Playground title", title, (0, -2.04, 2.45), 0.13, camera))


def make_monster(camera, plan: Dict[str, Any]):
    parent = bpy.data.objects.new("Monster rig parent", None)
    bpy.context.collection.objects.link(parent)
    parent.location = (0.82, -1.01, 0.05)
    group_add("monster", parent)

    # Body remains mostly behind wall; head and claws cross the edge.
    belly = make_sphere("Monster hidden rounded belly", (1.26, -0.82, 0.74), 0.50, MAT["monster_dark"], 56, scale=(0.90, 0.82, 1.08))
    head = make_sphere("Monster head peeking around wall", (0.78, -1.22, 1.33), 0.44, MAT["monster"], 64, scale=(1.04, 0.92, 1.02))
    snout = make_sphere("Monster tiny snout", (0.66, -1.58, 1.27), 0.115, MAT["monster_dark"], 32, scale=(1.1, 0.42, 0.72))

    eye_l = make_sphere("Monster left glowing eye", (0.55, -1.53, 1.43), 0.092, MAT["eye"], 32)
    eye_r = make_sphere("Monster right glowing eye", (0.80, -1.56, 1.44), 0.092, MAT["eye"], 32)
    pupil_l = make_sphere("Monster left pupil", (0.52, -1.625, 1.425), 0.034, MAT["pupil"], 20)
    pupil_r = make_sphere("Monster right pupil", (0.77, -1.655, 1.435), 0.034, MAT["pupil"], 20)

    brow_l = make_cube("Monster left soft brow", (0.545, -1.59, 1.535), (0.075, 0.014, 0.018), MAT["monster_dark"], bevel=0.012)
    brow_l.rotation_euler = (0, 0, math.radians(12))
    brow_r = make_cube("Monster right soft brow", (0.80, -1.62, 1.545), (0.075, 0.014, 0.018), MAT["monster_dark"], bevel=0.012)
    brow_r.rotation_euler = (0, 0, math.radians(-10))

    horn_l = make_cone("Monster left horn", (0.55, -1.22, 1.78), 0.105, 0.34, MAT["claw"], direction=(-0.35, -0.1, 1))
    horn_r = make_cone("Monster right horn", (0.92, -1.19, 1.77), 0.105, 0.34, MAT["claw"], direction=(0.35, -0.1, 1))

    claw_objs = []
    for i, z in enumerate([1.10, 0.94, 0.78]):
        claw_objs.append(make_cone(f"Monster visible wall claw {i + 1}", (0.885, -1.205, z), 0.036, 0.24, MAT["claw"], direction=(-1, -0.18, 0.04), vertices=24))

    smile = make_curve("Monster mischievous smile", [(0.56, -1.63, 1.18), (0.66, -1.70, 1.14), (0.84, -1.64, 1.19)], MAT["pupil"], bevel=0.011)
    cheek = make_sphere("Monster warm cheek glint", (0.97, -1.49, 1.22), 0.055, MAT["warm"], 20)
    rim_dot = make_sphere("Monster rim light shoulder", (1.00, -1.36, 1.02), 0.05, MAT["wall_edge"], 18)

    for obj in [belly, head, snout, eye_l, eye_r, pupil_l, pupil_r, brow_l, brow_r, horn_l, horn_r, smile, cheek, rim_dot, *claw_objs]:
        obj.parent = parent
        group_add("monster", obj)

    if plan_wants_labels(plan):
        label = make_text("Monster small label", "peek", (0.68, -1.72, 1.88), 0.10, camera, MAT["wall_edge"])
        label.parent = parent
        group_add("monster", label)
    return parent


def make_kid(camera, plan: Dict[str, Any]):
    parent = bpy.data.objects.new("Kid rig parent", None)
    bpy.context.collection.objects.link(parent)
    parent.location = (-1.58, -1.27, 0.02)
    group_add("kid", parent)

    head = make_sphere("Kid head", (-1.52, -1.22, 1.05), 0.18, MAT["kid_skin"], 36, scale=(0.96, 0.92, 1.05))
    hair = make_sphere("Kid hair cap", (-1.55, -1.25, 1.18), 0.18, MAT["kid_dark"], 28, scale=(1.0, 0.9, 0.54))
    body = make_cylinder("Kid hoodie", (-1.52, -1.22, 0.66), 0.17, 0.50, MAT["kid_blue"], 36)
    body.scale.x = 0.85
    pants = make_cylinder("Kid pants", (-1.52, -1.22, 0.28), 0.13, 0.42, MAT["kid_dark"], 28)
    backpack = make_cube("Kid backpack", (-1.75, -1.055, 0.62), (0.105, 0.090, 0.24), MAT["warm"], bevel=0.025)
    arm = make_cylinder("Kid small arm", (-1.32, -1.25, 0.64), 0.045, 0.38, MAT["kid_skin"], 18)
    arm.rotation_euler = (math.radians(65), 0, math.radians(-25))
    foot_l = make_cube("Kid left shoe", (-1.61, -1.30, 0.045), (0.105, 0.17, 0.04), MAT["kid_dark"], bevel=0.025)
    foot_r = make_cube("Kid right shoe", (-1.43, -1.16, 0.045), (0.105, 0.17, 0.04), MAT["kid_dark"], bevel=0.025)

    for obj in [head, hair, body, pants, backpack, arm, foot_l, foot_r]:
        obj.parent = parent
        group_add("kid", obj)

    if plan_wants_labels(plan):
        thought = make_text("Kid unaware label", "unaware", (-1.48, -1.55, 1.42), 0.09, camera, MAT["text"])
        thought.parent = parent
        group_add("kid", thought)
    return parent


def make_generic_subject(camera, plan: Dict[str, Any]):
    parent = bpy.data.objects.new("Generic subject parent", None)
    bpy.context.collection.objects.link(parent)
    parent.location = (0.0, -1.0, 0.02)
    body = make_sphere("Generic rounded subject", (0.0, -1.0, 0.82), 0.42, MAT["monster"], 48)
    eye_l = make_sphere("Generic left eye", (-0.12, -1.36, 1.0), 0.055, MAT["eye"], 20)
    eye_r = make_sphere("Generic right eye", (0.12, -1.36, 1.0), 0.055, MAT["eye"], 20)
    for obj in [body, eye_l, eye_r]:
        obj.parent = parent
        group_add("generic_subject", obj)
    return parent


def apply_lights(plan: Dict[str, Any]):
    add_light("AREA", "Playground large cool key softbox", (-3.8, -4.2, 5.8), 1550, (0.55, 0.72, 1.0), 5.7)
    add_light("AREA", "Playground monster cyan-green rim", (1.95, -1.82, 2.85), 1050, (0.18, 0.95, 0.68), 1.25)
    add_light("POINT", "Playground hidden warm practical", (1.46, -1.02, 1.32), 560, (1.0, 0.45, 0.16), 1.0)
    add_light("AREA", "Playground dim blue overhead fill", (0.0, 1.3, 5.3), 280, (0.70, 0.74, 1.0), 6.2)
    add_light("POINT", "Playground eye sparkle booster", (0.45, -2.1, 1.55), 80, (0.70, 1.0, 0.85), 1.0)


def animate_scene(plan: Dict[str, Any], camera, monster_parent, kid_parent, generic_parent, frame_number: int, total_frames: int):
    t = (frame_number - 1) / max(1, total_frames - 1)
    camera_plan = as_dict(plan.get("camera"))
    start = as_dict(camera_plan.get("start"))
    end = as_dict(camera_plan.get("end"))
    start_pos = as_vec3(start.get("position"), (-3.9, -6.7, 2.45))
    end_pos = as_vec3(end.get("position"), (-3.25, -5.75, 2.35))
    start_look = as_vec3(start.get("look_at"), (0.12, -0.20, 1.05))
    end_look = as_vec3(end.get("look_at"), (0.38, -0.45, 1.16))
    ease = 0.5 - 0.5 * math.cos(t * math.pi)
    camera.location = (
        start_pos[0] * (1 - ease) + end_pos[0] * ease + 0.05 * math.sin(t * math.pi * 1.2),
        start_pos[1] * (1 - ease) + end_pos[1] * ease,
        start_pos[2] * (1 - ease) + end_pos[2] * ease,
    )
    look = (
        start_look[0] * (1 - ease) + end_look[0] * ease,
        start_look[1] * (1 - ease) + end_look[1] * ease,
        start_look[2] * (1 - ease) + end_look[2] * ease,
    )
    look_at(camera, look)
    try:
        camera.data.dof.focus_distance = (mathutils.Vector(camera.location) - mathutils.Vector((0.68, -1.45, 1.36))).length
    except Exception:
        pass

    if monster_parent is not None:
        lean = clamp((t - 0.15) / 0.60, 0.0, 1.0)
        monster_parent.location.x = 0.82 - 0.28 * lean
        monster_parent.location.y = -1.01 - 0.055 * math.sin(t * math.pi)
        monster_parent.rotation_euler = (0, 0, math.radians(-4 - 8.5 * lean))

    if kid_parent is not None:
        kid_parent.location.x = -1.58 + 0.27 * t
        kid_parent.location.y = -1.27 + 0.09 * t
        kid_parent.rotation_euler = (0, 0, math.radians(3.0 * math.sin(t * math.pi * 2)))

    if generic_parent is not None:
        generic_parent.rotation_euler = (0, 0, math.radians(5 * math.sin(t * math.pi * 2)))

    # Subtle light flicker and haze drift.
    for obj in GROUPS.get("warm_light_panel", []):
        obj.scale.x = 0.034 + 0.010 * math.sin(frame_number * 0.55)
    for index, obj in enumerate(GROUPS.get("haze", [])):
        obj.location.x = -0.20 + 0.06 * math.sin(t * math.pi * 2 + index)


def load_payload(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)


def should_use_monster_scene(plan: Dict[str, Any], prompt: str) -> bool:
    text = json.dumps(plan).lower() + " " + prompt.lower()
    return "monster" in text or "scare" in text or "wall" in text


def main():
    if len(sys.argv) < 7:
        raise SystemExit("Expected: blender --background --python render-freeform-scene.py -- input.json out_dir frames fps width height")

    input_path = sys.argv[-6]
    output_dir = sys.argv[-5]
    frames = int(sys.argv[-4])
    fps = int(sys.argv[-3])
    width = int(sys.argv[-2])
    height = int(sys.argv[-1])

    os.makedirs(output_dir, exist_ok=True)
    payload = load_payload(input_path)
    plan = as_dict(payload.get("scene_plan"))
    prompt = clean_text(payload.get("prompt") or plan.get("prompt"), "", 400)

    clear_scene()
    init_materials()
    camera = setup_scene(width, height, fps, plan)
    make_stage(camera, plan)

    monster_parent = None
    kid_parent = None
    generic_parent = None

    if should_use_monster_scene(plan, prompt):
        monster_parent = make_monster(camera, plan)
        kid_parent = make_kid(camera, plan)
    else:
        generic_parent = make_generic_subject(camera, plan)

    apply_lights(plan)

    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end = frames

    for frame in range(1, frames + 1):
        scene.frame_set(frame)
        animate_scene(plan, camera, monster_parent, kid_parent, generic_parent, frame, frames)
        output_path = os.path.join(output_dir, f"frame_{frame:04d}.png")
        scene.render.filepath = output_path
        bpy.ops.render.render(write_still=True)

    print(json.dumps({"ok": True, "frames": frames, "output_dir": output_dir, "schema": plan.get("schema_version")}))


if __name__ == "__main__":
    main()
